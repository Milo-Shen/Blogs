import Tabs from '../Tabs';
import { snapshot } from '../../../../shared/test';

describe('components/repository/Tabs', () => {
  snapshot({
    component: Tabs,
    name: 'Tabs',
  });
});

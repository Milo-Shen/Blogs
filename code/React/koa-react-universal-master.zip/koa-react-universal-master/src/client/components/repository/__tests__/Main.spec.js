import Main from '../Main';
import { snapshot } from '../../../../shared/test';

describe('components/repository/Main', () => {
  snapshot({
    component: Main,
    name: 'Main',
  });
});

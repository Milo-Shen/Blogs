import Repository from '../Repository';
import { snapshot } from '../../../shared/test';

describe('components/container/Repository', () => {
  snapshot({
    component: Repository,
    name: 'Repository',
  });
});

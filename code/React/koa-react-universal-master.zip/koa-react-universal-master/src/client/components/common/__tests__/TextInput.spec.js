import TextInput from '../TextInput';
import { snapshot } from '../../../../shared/test';

describe('components/common/TextInput', () => {
  snapshot({
    component: TextInput,
    name: 'TextInput'
  });
});

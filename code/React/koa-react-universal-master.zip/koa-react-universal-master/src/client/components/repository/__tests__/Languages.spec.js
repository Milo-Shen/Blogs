import Languages from '../Languages';
import { snapshot } from '../../../../shared/test';

describe('components/repository/Languages', () => {
  snapshot({
    component: Languages,
    name: 'Languages',
  });
});

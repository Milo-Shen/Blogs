import favicon from 'koa-favicon';

export default favicon(`${__ROOT__}/src/assets/favicon.ico`);

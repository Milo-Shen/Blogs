export default async (ctx, next) => {
  ctx.body = {
    status: 0,
    info: 'this a users response!'
  }
}

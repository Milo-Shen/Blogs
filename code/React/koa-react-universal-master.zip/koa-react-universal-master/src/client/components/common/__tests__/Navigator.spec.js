import Navigator from '../Navigator';
import { snapshot } from '../../../../shared/test';

describe('components/common/Navigator', () => {
  snapshot({
    component: Navigator,
    name: 'Navigator',
  });
});

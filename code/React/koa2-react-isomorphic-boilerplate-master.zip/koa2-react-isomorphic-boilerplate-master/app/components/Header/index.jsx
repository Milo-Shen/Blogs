/**
 * Created at 16/5/17.
 * @Author Ling.
 * @Email i@zeroling.com
 */
import React, { Component } from 'react'
import './header.less'

export default class Header extends Component {
  render () {
    return (<header className="header">
      <h1>Koa2-React-isomorphic-Boilerplate</h1>
    </header>)
  }
}